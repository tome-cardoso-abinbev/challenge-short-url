package com.roadmap.challenge_short_url;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeShortUrlApplicationTests {

	@Test
	void contextLoads() {
	}

}
