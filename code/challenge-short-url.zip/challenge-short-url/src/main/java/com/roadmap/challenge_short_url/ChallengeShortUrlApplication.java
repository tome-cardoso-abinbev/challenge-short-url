package com.roadmap.challenge_short_url;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChallengeShortUrlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChallengeShortUrlApplication.class, args);
	}

}
