package com.roadmap.challenge_short_url.model;

import lombok.Data;

@Data
public class UrlRequest {
    private String url;
}
